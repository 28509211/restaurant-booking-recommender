# import mysql.connector
# from mysql.connector import Error
import json
import os 
def read_dict_from_file(filename):
    with open(filename, 'r', encoding='utf-8') as f:
        return json.load(f)


class DataBase :

    def __init__( self ):

        # self.connection = mysql.connector.connect(
        #         host='0.tcp.jp.ngrok.io',
        #         port=13672,  # NGROK 提供的端口
        #         user='tim',
        #         password='11027102',
        #         database='clientdatabase'
        # )

        # self.cursor = self.connection.cursor()
        # self.word_table = self.See_Data_In_Table( 'food_data' )

        #======================================================================================
        self.word_table = read_dict_from_file( r'CHATBOT/data.json' )
        self.store_table = read_dict_from_file( r'CHATBOT/storeinfo_review.json' )
        


    def See_Table( self ) :  #看有甚麼table
        query =  'SHOW TABLES' 
        self.cursor.execute( query )
        table = self.cursor.fetchall()

        for i in table :
            print( i )


    def See_Data_In_Table( self, table_name ) :
  
        query = f'SELECT * FROM {table_name}'
        self.cursor.execute(query)

        # 获取列名
        column_names = [desc[0] for desc in self.cursor.description]
        print("Column names:", column_names)

        # 获取查询结果
        rows = self.cursor.fetchall()

        # 创建一个字典以存储每列的数据
        column_data = {column: [] for column in column_names}

        # 遍历每一行，提取每列的数据
        for row in rows:
            for column_name, value in zip(column_names, row):
                if value != '' :
                    column_data[column_name].append(value)

        return column_data

    def Get_WordTable( self ) :  # 字典

        return self.word_table

    def Get_Store_ReviewTable( self ) :  # 字典

        return self.store_table

    def FindReview_Store_Table( self, store_name ) :  #找店家的評論
        review_folder = "CHATBOT/review"

        for stores in self.store_table :
            if stores[ 'store_name' ] == store_name :
                file_name = f"{stores[ 'store_name' ]}_review.txt"
                file_path = os.path.join(review_folder, file_name)

                if not os.path.isfile(file_path):
                    with open(file_path, 'w', encoding='utf-8') as f:
                        f.write(stores['reviews'])

                    return f"CHATBOT/review/{stores[ 'store_name' ]}_review.txt"
                else :
                    return f"CHATBOT/review/{stores[ 'store_name' ]}_review.txt"


    def FindAddress_Store_Table( self, store_name ) :  #找店家的地址
        for stores in self.store_table :
            if stores[ 'store_name' ] == store_name :       
                return stores['location']
        
        return ""

       

global_db = DataBase()


# db = DataBase()
# db.FindReview_Store_Table( "一品魚麵" )

# print( db.Get_Store_ReviewTable() )

# from langchain_community.llms import HuggingFacePipeline
# from langchain.chains import LLMChain
# from langchain.prompts import PromptTemplate
# from langchain_community.document_loaders import TextLoader
# from langchain.text_splitter import RecursiveCharacterTextSplitter
# from langchain_community.embeddings import HuggingFaceInferenceAPIEmbeddings
# import os
# from langchain_community.vectorstores import FAISS
# from langchain_huggingface import HuggingFaceEmbeddings

# loader = TextLoader( 'test_review.txt', encoding='utf-8' )
# pages = loader.load()

# text_splitter = RecursiveCharacterTextSplitter(
#             chunk_size=100,
#             chunk_overlap=30,
#         )

# docs = text_splitter.split_documents( pages ) #切

# print(docs)