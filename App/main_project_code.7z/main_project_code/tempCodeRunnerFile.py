d = threading.Thread(target=send_messages_from_queue, args=(message_queue, socketio))
    send_thread.start()