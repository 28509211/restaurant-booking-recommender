import mysql.connector
from mysql.connector import Error


connection = mysql.connector.connect(
        host='0.tcp.jp.ngrok.io',
        port=13672,  # NGROK 提供的端口
        user='tim',
        password='11027102',
        database='clientdatabase'
)
    
# 確認是否已連接
if connection.is_connected():
    print("已成功連接到 MySQL 資料庫")

# 建立游標
cursor = connection.cursor()

# 執行查詢語句，提取 food_data 表中的 store 欄位
query = "SELECT store FROM food_data"
cursor.execute(query)

# 提取所有結果
stores = cursor.fetchall()

for store in stores:
    print(store[0])

input("按 Enter 鍵結束程式...")