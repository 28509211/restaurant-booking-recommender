import spacy
from spacy import displacy
import user_information
from spacy_function import* 

test_data = []


test = "我想要在3.10睡覺"


AllFunction_Ner( test )

print( user_ner )

