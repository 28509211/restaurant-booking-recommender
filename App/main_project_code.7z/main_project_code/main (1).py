from flask import Flask, render_template, request
from flask_socketio import SocketIO, join_room, leave_room
import threading
from transformers import AutoTokenizer, AutoModelForCausalLM
from uuid import uuid4
import torch
from engineio.async_drivers import gevent
from user_information import*
from multiprocessing import Process, Manager, Queue
import time 
from pyngrok import ngrok
from spacy_function import NER  # 匯入 Place_Answer_InLabel


app = Flask(__name__)
socketio = SocketIO( app, async_mode='gevent' )


user_rooms = {}  # 紀錄user登陸網站的編碼


def send_messages_from_queue(message_queu, socketio):   #存queue中抓第一個訊息傳送到window上
    while True:
        if not message_queue.empty():
            message, room_id = message_queue.get()
            socketio.emit('message', message, room=room_id)   # 傳訊息到 server          
        time.sleep(0.1) 

# def send_restaurant_list(ner_result, room_id):
#     print(f"Sending restaurant list to room {room_id} with ner_result: {ner_result}")
    
#     store_names = ner_result.get("STORE", "").split("、")
#     if len(store_names) > 1:
#         data = {"restaurants": store_names}
#         socketio.emit("restaurant_list", data, room=room_id)
#         print(f"Multiple restaurants sent to room {room_id}: {store_names}")
#     elif len(store_names) == 1 and store_names[0]:
#         message = f"確認選擇的店家：{store_names[0]}"
#         socketio.emit("message", message, room=room_id)
#         print(f"Single restaurant sent to room {room_id}: {store_names[0]}")
#     else:
#         socketio.emit("message", "無法找到相關的店家", room=room_id)
#         print("No restaurant found, sent failure message.")





@socketio.on('selected_restaurant')
def handle_selected_restaurant( data ):
    user_sid = request.sid
    room_id = user_rooms.get(user_sid)

    selected_restaurant = data.get("selected_restaurant")
    print(f"User in room {room_id} selected restaurant: {selected_restaurant}")
    
    # 檢查是否包含 selected_restaurant 並提取店名
    if data and "selected_restaurant" in data:
        selected_restaurant_full = data.get("selected_restaurant")
        print(f"Full message from Android: {selected_restaurant_full}")
        
        # 去掉 "選擇的餐廳是：" 並保留後面的店名
        selected_restaurant = selected_restaurant_full.replace("選擇的餐廳是：", "").strip()
        print(f"Parsed restaurant name: {selected_restaurant}")

    global shared_usechatbot
    shared_usechatbot[room_id] = [True, selected_restaurant, True, True]
    
    # 傳送確認消息回給 Android 客戶端
    socketio.emit("message", f"已確認選擇的店家：{selected_restaurant}", room=room_id)
    # # 使用 room_id 直接從 shared_usechatbot 獲取用戶實例
    # if room_id in shared_usechatbot:
    #     chatbot_data = shared_usechatbot[room_id]
    #     if isinstance(chatbot_data, list) and len(chatbot_data) >= 3:
    #         user_instance = chatbot_data[2]  # 獲取用戶實例
            
    #         # 檢查用戶實例是否存在，並且有 'ner_result' 屬性
    #         if user_instance:
    #             ner_result["STORE"] = selected_restaurant  # 更新選擇的餐廳
    #             socketio.emit("message", f"已確認選擇的店家：{selected_restaurant}", room=room_id)
    #         else:
    #             print(f"無法找到 room_id {room_id} 對應的 User 實例")
    #             socketio.emit("message", "無法處理您的請求，請重試", room=room_id)
    #     else:
    #         print(f"Room ID {room_id} 的資料結構不正確")
    #         socketio.emit("message", "無法處理您的請求，請重試", room=room_id)
    # else:
    #     print(f"Room ID {room_id} 不存在於 shared_usechatbot")
    #     socketio.emit("message", "無法處理您的請求，請重試", room=room_id)





# @socketio.on('selected_restaurant')
# def handle_selected_restaurant(data):
#     user_sid = request.sid
#     room_id = user_rooms.get(user_sid)

#     selected_restaurant = data.get("selected_restaurant")
#     print(f"User in room {room_id} selected restaurant: {selected_restaurant}")

#     if room_id in shared_usechatbot:
#         chatbot_data = shared_usechatbot[room_id]
#         if isinstance(chatbot_data, list) and len(chatbot_data) >= 3:
#             user_instance = chatbot_data[2]  # 獲取用戶實例
            
#             # 更新 NER 結果
#             if user_instance:
#                 user_instance.ner_result["STORE"] = selected_restaurant  # 更新選擇的餐廳
#                 socketio.emit("message", f"已確認選擇的店家：{selected_restaurant}", room=room_id)
#             else:
#                 print(f"無法找到 room_id {room_id} 對應的 User 實例")
#                 socketio.emit("message", "無法處理您的請求，請重試", room=room_id)
#         else:
#             print(f"Room ID {room_id} 的資料結構不正確")
#             socketio.emit("message", "無法處理您的請求，請重試", room=room_id)
#     else:
#         print(f"Room ID {room_id} 不存在於 shared_usechatbot")
#         socketio.emit("message", "無法處理您的請求，請重試", room=room_id)






def Chatbot( room_id, shared_usechatbot, message_queue ) :

    user = User()  # 嘗試初始化 User

    DO_FUNCTION = False

    nlu_last = "聊天"
    nlu_result = "聊天"

    socketio.emit('message', "準備完畢......", room=room_id)   # 傳訊息到 server      
    print( "--------------------------------------Model ok------------------------------------")

    while shared_usechatbot[room_id][2]:
        if shared_usechatbot[room_id][0] :  # 接收到訊息
            

            message = shared_usechatbot[room_id][1]   # user talk
            # message_queue.put([message, room_id])
            shared_usechatbot[room_id] = [False, "", True, shared_usechatbot[room_id][3]]

            if shared_usechatbot[room_id][3] == True:
                user.Change_NER( message, "STORE")
            else:
                ner_result = user.Use_NER( message, debug=False ) # ner判別, user talk 已記錄在對話歷史中
                ner_message = "NER PREDICT: " + str( ner_result )
                print( ner_message )

                # message_queue.put([ner_message, room_id])   # chatbot talk( 把ner透露在網站上 )
                # shared_usechatbot[room_id] = [False, "", True]

                
                nlu_last = nlu_result #更新 nlu_last


                nlu_result = user.Use_NLU( message, debug=False )  # nlu 判別
                nlu_message = "NLU PREDICT: " + str( nlu_result )
                print( nlu_message )

                # message_queue.put([nlu_message, room_id])   # chatbot talk( 把nlu透露在網站上 )
                # shared_usechatbot[room_id] = [False, "", True]

                if nlu_last != nlu_result :       # 若前一次使用的功能和現在使用的不一樣(意圖轉換) 清除紀錄(為了選擇較正確的dp)
                    global_dp.Clear_Record_Ask_Times_and_Finded_Times_and_Not_Finded( global_cp,  nlu_last )
                    user.Clear_History()  # 清除對話紀錄資訊
                    user.Set_Input( message ) #把這次偵測到的新功能的句子重新新增到history

                print( "history: ", end="" )
                print( user.Get_History_Input() )


                store_value = ner_result.get("STORE", "")
                if store_value:
                    maybe_store_list = store_value.split("、")  # 分割多個店名
                    print("找到的店名列表:", maybe_store_list)
                    
                    if len(maybe_store_list) > 1:  # 如果有多個店名
                        # 發送多店名列表給 Android 端進行選擇
                        socketio.emit('restaurant_list', {"restaurants": maybe_store_list}, room=room_id)
                        print("Multiple restaurants sent to user for selection:", maybe_store_list)
                    else:
                        # 單一店名情況，直接處理
                        selected_store = maybe_store_list[0]
                        print(f"Single store found and selected: {selected_store}")
                        # 你可以直接設置選定的店家到 ner_result
                        user.Change_NER(selected_store, "STORE")
                # else:
                #     print("無法找到相關的店家")

                        
                # 設置 store_data，這裡假設從 ner_result 中獲取
                store_data = ner_result.get("STORE") if "STORE" in ner_result else None

                            
                dp_sentence = user.Use_Dp( nlu_result ) # dp 判別
                print( "Dialogue Policy: " + dp_sentence )

                # message_queue.put([dp_sentence, room_id])   # chatbot talk( 把dp透露在網站上 )
                # shared_usechatbot[room_id] = [False, "", True]

                if "準備執行" in dp_sentence :
                    user.Clear_History()  # 清除對話紀錄資訊
                    global_dp.Clear_Record_Ask_Times_and_Finded_Times_and_Not_Finded( global_cp,  nlu_last )
                    DO_FUNCTION = True   # 已收集完該功能的 NER準備要執行該功能
                
                if nlu_result == "聊天" :
                    answer =  user.Use_NLG_Chat( message )
                else :
                    # print( "dp -> dialogue: " + dp_sentence )
                    answer =  user.Use_NLG_Chat( dp_sentence, dp_mode=True )

                user.Set_Input( message ) 

                message_queue.put([answer, room_id])   # chatbot talk( 把nlg透露在網站上 )
                shared_usechatbot[room_id] = [False, "", True, False]

                if DO_FUNCTION :
                    if nlu_result == "推薦" :
                        FOOD_ADJ = user.User_Get_Ner_Food_Adj_MergeList()
                        print( "FOOD ADJ: ", FOOD_ADJ )
                        Rec_first_store_list = user.Use_Recommand( FOOD_ADJ )
                        print("推薦店家:", Rec_first_store_list )
                        user.Set_Ner_Label( "STORE", Rec_first_store_list )
                        socketio.emit('recommendation_list', {'recommendations': Rec_first_store_list}, room=room_id)
                    elif nlu_result == "導航":
                        address = ner_result.get("ADDRESS", "")
                        user.Use_Map(address, room_id, message_queue, socketio)
                    elif nlu_result == "訂位":
                        user.Use_NLG_Reserve(message, store_data)
                    elif nlu_result == "詢問":
                        question = user.ner.Get_User_NER_Label( "QUESTION" )
                        answer = user.Use_Ask_Question( question, "CHATBOT/test_review.txt")
                        message_queue.put([answer, room_id])   # chatbot talk( 把nlg透露在網站上 )
                        shared_usechatbot[room_id] = [False, "", True, False]
                    DO_FUNCTION = False


                    user.Delete_Executed_Task()   # 刪除在stack中已執行完畢的任務
                    global_dp.Clear_Record_Ask_Times_and_Finded_Times_and_Not_Finded( global_cp,  nlu_last )
                    user.Clear_History()  # 清除對話紀錄資訊












@app.route('/')
def index():
    return render_template('index.html')






@socketio.on('connect') 
def handle_connect():
    new_user = request.sid
    room_id = str(uuid4())
    user_rooms[new_user] = room_id
    join_room(room_id)
    print(f"New room created: {room_id}")
    print(user_rooms)

    global shared_usechatbot
    # 確保在初始化時只創建一個 User 實例
    if room_id not in shared_usechatbot:
        shared_usechatbot[room_id] = [False, "", True, False]  # 初始化 User 實例

    # 啟動 Chatbot
    a = threading.Thread(target=Chatbot, args=(room_id, shared_usechatbot, message_queue))
    a.start()


@socketio.on( 'disconnect' ) 
def handle_disconnect():
    global shared_usechatbot

    user_name = request.sid
    if user_name in user_rooms:
        room_id = user_rooms[ user_name ]
        print("==========================DISCONNECT==================================")

        shared_usechatbot[room_id] = [False, "", False, False]


        shared_usechatbot.pop(room_id)
        leave_room( room_id ) 
        del user_rooms[ user_name ]  


@socketio.on( 'message' )
def handle_message( message ):
    user_name = request.sid  
    room_id = user_rooms.get( user_name )
    print( f"Message received from room {room_id}: {message}" )

    global shared_usechatbot
    
    # 檢查是否包含 "選擇的餐廳是：" 前綴
    if "選擇的餐廳是：" in message:
        # 去掉前綴並保留店名部分
        selected_restaurant = message.replace("選擇的餐廳是：", "").strip()
        print(f"Parsed restaurant name: {selected_restaurant}")

        # 更新選擇的店家到 ner_result
        shared_usechatbot[room_id] = [True, selected_restaurant, True, True]

        # 傳送確認消息回給 Android 客戶端
        socketio.emit("message", f"已確認選擇的店家：{selected_restaurant}", room=room_id)
    else:
        # 處理一般訊息
        shared_usechatbot[room_id] = [True, message, True, False]
        
        # 日誌輸出確認 shared_usechatbot 是否正確寫入
        print(f"Updated shared_usechatbot[{room_id}] to: {shared_usechatbot[room_id]}")
        
    #shared_usechatbot[room_id] = [True, message, True, False]
    # Broadcast the message to the room
    # socketio.emit( 'message', data, room=room_id )

    # # Generate reply
    # reply_message = generate_reply( data )
    # print( f"Reply: { reply_message }" )
    # socketio.emit( 'message', reply_message, room=room_id )


    # 日誌輸出確認 shared_usechatbot 是否正確寫入
    #print(f"Updated shared_usechatbot[{room_id}] to: {shared_usechatbot[room_id]}")
    

def run_server():

    
    #public_url = ngrok.connect(5001)  # 5000是Flask的端口
    #print("Flask App URL:", public_url)

    print("----------------RUN SERVER-----------------")
    socketio.run(app, host='0.0.0.0', port=5000)

if __name__ == '__main__':
    print("Current async mode:", socketio.async_mode)
    manager = Manager()
    message_queue = Queue()  # 每個process傳送的訊息會到這裡，然後server會從最前面的開始把資料傳到網站上
    shared_usechatbot = manager.dict()
    
    send_thread = threading.Thread(target=send_messages_from_queue, args=(message_queue, socketio))
    send_thread.start()

    run_server()