from transformers import AutoTokenizer, AutoModelForCausalLM
import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, BitsAndBytesConfig
from langchain_community.llms import HuggingFacePipeline
from langchain.chains import LLMChain
from langchain.prompts import PromptTemplate
from langchain_community.document_loaders import TextLoader
from langchain.text_splitter import RecursiveCharacterTextSplitter
from langchain_community.embeddings import HuggingFaceInferenceAPIEmbeddings
import os
from langchain_community.vectorstores import FAISS
from langchain_huggingface import HuggingFaceEmbeddings
from sentence_transformers import SentenceTransformer
from llamafactory.chat import ChatModel
from llamafactory.extras.misc import torch_gc
import time

text_splitter = RecursiveCharacterTextSplitter(
            chunk_size=100,
            chunk_overlap=30,
        )

loader = TextLoader( "CHATBOT/test_review.txt", encoding = 'utf-8' )
print( loader )
pages = loader.load()
print( pages )
docs = text_splitter.split_documents( pages ) #切
print( docs )

# db = FAISS.from_documents( docs, embeddings ) #把文檔轉向量
# docs = text_splitter.split_documents( pages ) #切

# print(docs)