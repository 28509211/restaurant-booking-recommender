import openpyxl

def Opentable():
    wb = openpyxl.load_workbook('CHATBOT/NER_NLU/table.xlsx')
    sheet = wb.worksheets[0]
    ner_labels = { 'TIME2': [], 'FOOD': [], 'ADJ': [], 'PEOPLE': [], "TIME": [], "STORE": [], "PLACE": [], "DATE": [] }
    
    for column in range(1, sheet.max_column + 1):
        label = sheet.cell(row=1, column=column).value  # Get header label
        if label in ner_labels:
            for row in range(2, sheet.max_row + 1):  # Start from row 2 to skip headers
                cell_value = sheet.cell(row=row, column=column).value
                if cell_value is not None:
                    ner_labels[label].append(cell_value)
    
    return ner_labels


ner_labels_table = Opentable()

print("Loaded NER labels:", ner_labels_table)